from pyrogram import Client
import os
import dotenv
import sqlite3
import datetime
from time import sleep

from config import chat_id, users_forward, time_sleep, dislike, limit_get_history

dotenv.load_dotenv('edit.env')

api_id = os.environ.get('API_ID')

api_hash = os.environ.get('API_HASH')

conn = sqlite3.connect('messages.db')
cur = conn.cursor()
cur.execute("""CREATE TABLE IF NOT EXISTS messages(
   message_id INT,
   chat_id INT);
""")
conn.commit()
app = Client("my_account", api_id=api_id, api_hash=api_hash)


def main():
    with app:
        history_chat(app)


def history_chat(client):
    try:
        for chat in chat_id:
            messages_id = []
            for message in client.get_chat_history(chat, limit_get_history):
                if message.reactions != None:
                    for reaction in message.reactions:
                        if reaction.emoji == '👎' and reaction.count >= dislike:
                            cur.execute("SELECT * FROM messages WHERE message_id = ?AND chat_id = ?",
                                        (message.id, chat))
                            data = cur.fetchall()
                            if len(data) == 0:
                                cur.execute("INSERT INTO messages VALUES(?, ?);", (message.id, chat))
                                conn.commit()
                                messages_id.append(message.id)
                            sleep(0.1)
            if len(messages_id) != 0:
                my_handler(client, chat, messages_id)
    except Exception as exc:
        print('Ошибка', datetime.datetime.now())
        print(exc)


@app.on_message()
def my_handler(client, chat_from, messages):
    try:
        for chat_to in users_forward:
            client.forward_messages(chat_to, chat_from, messages)
            sleep(1)
    except Exception as exc:
        print('Ошибка', datetime.datetime.now())
        print(exc)


if __name__ == '__main__':
    while True:
        main()
        print(datetime.datetime.now())
        sleep(time_sleep)
